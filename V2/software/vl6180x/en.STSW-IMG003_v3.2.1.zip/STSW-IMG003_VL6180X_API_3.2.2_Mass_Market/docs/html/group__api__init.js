var group__api__init =
[
    [ "VL6180x_WaitDeviceBooted", "group__api__init.html#gafa80e61fda3ac8380f462a7813f73a5e", null ],
    [ "VL6180x_InitData", "group__api__init.html#gae02c011152edd1bdcbe46f9a297306eb", null ],
    [ "VL6180x_SetupGPIO1", "group__api__init.html#ga56f817571389297cf6d6ea0478118e6a", null ],
    [ "VL6180x_Prepare", "group__api__init.html#ga1c49fcc18d18625003c6b08b2617d1bc", null ]
];