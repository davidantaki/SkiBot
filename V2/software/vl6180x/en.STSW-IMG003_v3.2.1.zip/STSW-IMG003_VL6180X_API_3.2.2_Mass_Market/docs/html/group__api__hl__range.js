var group__api__hl__range =
[
    [ "VL6180x_RangeClearInterrupt", "group__api__hl__range.html#gafaabe2450705319f9335bfea7fed737b", null ],
    [ "VL6180x_RangeStartContinuousMode", "group__api__hl__range.html#ga293131fd8c1403182b5216ea7a7fd9d2", null ],
    [ "VL6180x_RangeStartSingleShot", "group__api__hl__range.html#gadba565ca05325cac23b2d0a6d0ee2bbb", null ],
    [ "VL6180x_RangeSetMaxConvergenceTime", "group__api__hl__range.html#ga394c0ce7c6a2816d5111030060e13d79", null ],
    [ "VL6180x_RangePollMeasurement", "group__api__hl__range.html#ga9859335233f7af61537a07150e51ca4e", null ],
    [ "VL6180x_RangeGetMeasurementIfReady", "group__api__hl__range.html#ga1ea9203b5ccc473e1c3bfa3096666f7f", null ],
    [ "VL6180x_RangeGetMeasurement", "group__api__hl__range.html#gab29eb306d55d7699976c196ed4f55893", null ],
    [ "VL6180x_RangeGetResult", "group__api__hl__range.html#ga0b7265e77741ca00c9e576175074fedf", null ],
    [ "VL6180x_RangeConfigInterrupt", "group__api__hl__range.html#ga3d537d493e9adcf98a431cd6f5df10da", null ],
    [ "VL6180x_RangeGetInterruptStatus", "group__api__hl__range.html#ga72503f510ed32b728c73adaf53e305a9", null ],
    [ "VL6180x_RangeGetStatusErrString", "group__api__hl__range.html#ga76130550de8fcb15f5371d2e267551a4", null ],
    [ "VL6180x_RangeStatusErrString", "group__api__hl__range.html#gaf3050e75f14e6c60436572eb6238f20a", null ]
];