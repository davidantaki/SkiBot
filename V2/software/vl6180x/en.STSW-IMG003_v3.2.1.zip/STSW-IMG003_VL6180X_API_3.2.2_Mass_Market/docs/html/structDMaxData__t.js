var structDMaxData__t =
[
    [ "ambTuningWindowFactor_K", "structDMaxData__t.html#a84f66026688580e60d36f797f6c2a297", null ],
    [ "retSignalAt400mm", "structDMaxData__t.html#a11936a62c4891a56d89fd2b44fc8091e", null ],
    [ "snrLimit_K", "structDMaxData__t.html#af445a7c777bc024bd507be1c6fe1579b", null ],
    [ "ClipSnrLimit", "structDMaxData__t.html#af5983319c8771c424ff2969a271a1318", null ]
];