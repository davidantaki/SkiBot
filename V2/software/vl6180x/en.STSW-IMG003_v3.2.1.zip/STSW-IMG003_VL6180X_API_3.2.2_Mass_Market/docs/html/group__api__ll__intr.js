var group__api__ll__intr =
[
    [ "VL6180x_ClearErrorInterrupt", "group__api__ll__intr.html#ga7f30a021f9076b35fc172571aa0f994c", null ],
    [ "VL6180x_ClearAllInterrupt", "group__api__ll__intr.html#ga0aa6faef1beaf59c7bcebd5ec7a5bd37", null ],
    [ "VL6180x_GetInterruptStatus", "group__api__ll__intr.html#ga3d17960f31e7e17dc30082e2a9cce06f", null ],
    [ "VL6180x_ClearInterrupt", "group__api__ll__intr.html#gac029e6ec7d317febdeea115cfb887b21", null ]
];