var files_dup =
[
    [ "config", "dir_9f351d46ce3cc29445a41dc3a31e6919.html", "dir_9f351d46ce3cc29445a41dc3a31e6919" ],
    [ "core", "dir_4270bfced15e0e73154b13468c7c9ad9.html", "dir_4270bfced15e0e73154b13468c7c9ad9" ],
    [ "platform", "dir_c5a52a81292cf9a5167198f4f346d6d9.html", "dir_c5a52a81292cf9a5167198f4f346d6d9" ]
];