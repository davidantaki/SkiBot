var modules =
[
    [ "API Low Level Functions", "group__api__ll.html", "group__api__ll" ],
    [ "API High Level Functions", "group__api__hl.html", "group__api__hl" ],
    [ "Device registers & masks definitions", "group__device__regdef.html", "group__device__regdef" ],
    [ "Platform", "group__api__platform.html", "group__api__platform" ],
    [ "Basic type definition", "group__porting__type.html", "group__porting__type" ],
    [ "Configuration", "group__api__config.html", "group__api__config" ],
    [ "CCI to RAW I2C translation layer", "group__cci__i2c.html", "group__cci__i2c" ]
];