var group__api__hl__als =
[
    [ "VL6180x_AlsClearInterrupt", "group__api__hl__als.html#ga1aa369f14dfc3f8552d1b95341a6ef6c", null ],
    [ "VL6180x_AlsPollMeasurement", "group__api__hl__als.html#gaa0414e367fbb98ac9eaf07cfea3890f5", null ],
    [ "VL6180x_AlsGetMeasurement", "group__api__hl__als.html#ga7821c3110e24a3a233c2911a4e9ff3d6", null ],
    [ "VL6180x_AlsConfigInterrupt", "group__api__hl__als.html#ga8a1fae79135ed79edffa48efe5a08c2c", null ],
    [ "VL6180x_AlsSetIntegrationPeriod", "group__api__hl__als.html#ga4fe003348472d12808a3700f6adbaf05", null ],
    [ "VL6180x_AlsSetInterMeasurementPeriod", "group__api__hl__als.html#ga20d0732847ec870b8680dfa92140904d", null ],
    [ "VL6180x_AlsSetAnalogueGain", "group__api__hl__als.html#ga8d788d935472ab660549bce00991c0f2", null ],
    [ "VL6180x_AlsSetThresholds", "group__api__hl__als.html#gaeaf6b61992124aac6ced0d9d2a90e8ab", null ],
    [ "VL6180x_AlsGetInterruptStatus", "group__api__hl__als.html#ga8be6fe0595f0d40116c0e265469cc7e0", null ]
];