var group__porting__type =
[
    [ "uint32_t", "group__porting__type.html#ga435d1572bf3f880d55459d9805097f62", null ],
    [ "int32_t", "group__porting__type.html#ga32f2e37ee053cf2ce8ca28d1f74630e5", null ],
    [ "uint16_t", "group__porting__type.html#ga273cf69d639a59973b6019625df33e30", null ],
    [ "int16_t", "group__porting__type.html#gaa343fa3b3d06292b959ffdd4c4703b06", null ],
    [ "uint8_t", "group__porting__type.html#gaba7bc1797add20fe3efdf37ced1182c5", null ],
    [ "int8_t", "group__porting__type.html#gaef44329758059c91c76d334e8fc09700", null ]
];