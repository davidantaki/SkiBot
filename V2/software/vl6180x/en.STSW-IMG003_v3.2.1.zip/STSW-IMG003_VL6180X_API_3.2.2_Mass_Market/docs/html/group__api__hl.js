var group__api__hl =
[
    [ "Init functions", "group__api__init.html", "group__api__init" ],
    [ "Ranging functions", "group__api__hl__range.html", "group__api__hl__range" ],
    [ "ALS functions", "group__api__hl__als.html", "group__api__hl__als" ]
];