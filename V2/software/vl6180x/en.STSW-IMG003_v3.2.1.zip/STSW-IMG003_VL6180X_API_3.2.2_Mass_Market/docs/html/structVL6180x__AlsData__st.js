var structVL6180x__AlsData__st =
[
    [ "lux", "structVL6180x__AlsData__st.html#a2d2800a0fee45defbcea3ccafcf13a51", null ],
    [ "errorStatus", "structVL6180x__AlsData__st.html#a54a4bbba6d59bd9bf39b4e0e7e2983ae", null ]
];