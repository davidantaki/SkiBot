var group__api__ll__range__calibration =
[
    [ "VL6180x_GetOffsetCalibrationData", "group__api__ll__range__calibration.html#ga0a114fb818b23cb4183ea92f3dba32e5", null ],
    [ "VL6180x_SetOffsetCalibrationData", "group__api__ll__range__calibration.html#ga0266e13ebfd94e2f7aeb35ede95023c1", null ],
    [ "VL6180x_SetXTalkCompensationRate", "group__api__ll__range__calibration.html#ga8437ec4ddcec8d520844d6d2d8adfef3", null ]
];