var group__api__ll__init =
[
    [ "VL6180x_StaticInit", "group__api__ll__init.html#ga7122b5aa6ceeb1391820257692681cec", null ]
];