var vl6180x__i2c_8c =
[
    [ "DECL_I2C_BUFFER", "vl6180x__i2c_8c.html#a669a440fe7224cf4fd875bf5ef333b87", null ],
    [ "VL6180x_GetI2cBuffer", "vl6180x__i2c_8c.html#a6b3a61750071a21d166dade2c2cb9afa", null ],
    [ "VL6180x_WrByte", "group__api__reg.html#ga62b89156a7eca29eaaf0ec898c415f9a", null ],
    [ "VL6180x_WrWord", "group__api__reg.html#ga8541a0f48e071655502784c75cefbd90", null ],
    [ "VL6180x_WrDWord", "group__api__reg.html#ga08543a3d946eb489754fba6f6a1444d4", null ],
    [ "VL6180x_UpdateByte", "group__api__reg.html#ga2f013ea06f2130bb10b705199e0ef8ea", null ],
    [ "VL6180x_RdByte", "group__api__reg.html#ga310875666a22dcee6c7f65adc1afc182", null ],
    [ "VL6180x_RdWord", "group__api__reg.html#gaff9432f6cd34619efb68865c8ffca653", null ],
    [ "VL6180x_RdDWord", "group__api__reg.html#gaacbb5b1aa5b200a8ebad0bf0941c1c55", null ],
    [ "VL6180x_RdMulti", "group__api__reg.html#ga64139a1b517698faae6ebf07cc70bd41", null ]
];